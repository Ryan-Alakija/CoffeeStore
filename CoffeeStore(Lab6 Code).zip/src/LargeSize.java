public class LargeSize extends CoffeeDecorator {
    public LargeSize(Coffee coffee) {
        super(coffee);
    }

    @Override
    public void addTopping(Coffee coffee) {
        coffee.addTopping(this.coffee);
        this.coffee = coffee;
    }

    @Override
    public String printCoffee() {
        return this.coffee.printCoffee() + "-large size";
    }

    @Override
    public Double cost() {
        return this.coffee.cost() + 1.0;
    }
}

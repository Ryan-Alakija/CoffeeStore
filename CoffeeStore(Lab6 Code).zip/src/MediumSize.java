public class MediumSize extends CoffeeDecorator {
    public MediumSize(Coffee coffee) {
        super(coffee);
    }

    @Override
    public void addTopping(Coffee coffee) {
        coffee.addTopping(this.coffee);
        this.coffee = coffee;
    }

    @Override
    public String printCoffee() {
        return this.coffee.printCoffee() + "-medium size";
    }

    @Override
    public Double cost() {
        return this.coffee.cost() + 0.5;
    }
}

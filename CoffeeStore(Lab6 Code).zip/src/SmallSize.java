 public class SmallSize extends CoffeeDecorator {
    public SmallSize(Coffee coffee) {
        super(coffee);
    }

    @Override
    public void addTopping(Coffee coffee) {
        coffee.addTopping(this.coffee);
        this.coffee = coffee;
    }

    @Override
    public String printCoffee() {
        return this.coffee.printCoffee() + "-small size";
    }

    @Override
    public Double cost() {
        return 0.0;
    }
}

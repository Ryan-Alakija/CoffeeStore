import java.io.FileReader;
import java.io.BufferedReader;
import java.io.FileWriter;
import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Stack;

public class Main {

    final static int INPUT_ARR_SIZE = 6;
    private static int[] inpArr = new int[6]; //initializes the array that stores various amount of coffee ingredients throughout the program
        //INPUT_ARR_SIZE
    public static void main(String[] args) {

        ArrayList<String> Item = new ArrayList<> ();
        ArrayList<Double> price = new ArrayList<> ();
        Stack<String> order = new Stack<>();
        Stack<Coffee> coffeeOrders = new Stack<>();
        int i = 0;
        int input = 0;
        Scanner CafeApplication = new Scanner(System.in);
        System.out.println("Cafe Application Running...");

        while (input != 1) {
            System.out.println("Press 1 : Read Inventory");
            System.out.println("Press 2 : Create Coffee Order");
            System.out.println("Press 3 : Update Inventory");
            System.out.println("Press 4 : Update log file");
            System.out.println("Press 5 : Exit the application");
            switch (CafeApplication.nextLine()) {
                case "1":
                    System.out.println("Current items in the inventory: ");
                    inventoryReader();
                    break;
                case "2":
                    if (inpArr[0] <= 0) {
                        System.out.println("Out of Coffee. Visit us later.");
                        break;
                    }
                    do {
                        if (inpArr[0] > 0) {
                            coffeeOrders.addAll(CreateOrder());
                            inpArr[0]--;
                        }
                        else {
                            System.out.println("Order Completed. No more coffees.");
                            break;
                        }
                        System.out.println("Do you want to add another coffee to this order? Yes or No");
                    }
                    while (!(CafeApplication.nextLine().equals("No")) && !(CafeApplication.nextLine().equals("no")));

                    for (i = 0; i < coffeeOrders.size(); ++i) {
                        Item.add(coffeeOrders.get(i).printCoffee());
                        price.add(coffeeOrders.get(i).cost());
                    }
                    order.push(PrintOrder(Item, price));
                    break;
                case "3":
                    inventoryWriter(inpArr);
                    break;
                case "4":
                    logWriter(order);
                    break;
                case "5":
                    inventoryWriter(inpArr);
                    if (!order.empty()) {
                        logWriter(order);
                    }
                    input = 1; //this ends the while loop
                    break;
                default:
                    System.out.println("Invalid Selection. Please Try Again"); //if the user gives any other input aside from any input matching any of the above cases
                    break;
            }
        }
    }

    public static String PrintOrder(ArrayList<String> Item, ArrayList<Double> price){
        StringBuilder order = new StringBuilder();
        order.append("RECEIPT\n");
        double total = 0;
        for (int i=1; i<=Item.size(); i++){
            order.append("Item "+i+": "+Item.get(i-1)+" | cost:"+price.get(i-1)+ "\n");
            total = total + price.get(i-1);
        }
        order.append("TOTAL COST OF ORDER: " +total+ "\n");
        return order.toString();
    }

    public static ArrayList<Coffee> CreateOrder() {
        Scanner userFeedback = new Scanner(System.in);
        ArrayList<Coffee> coffeeOrder = new ArrayList<>(); //initializes the array to add each coffee order
        Coffee basicCoffee = new BasicCoffee(); //initializes the coffee object that will be added to the array after the whole process
        boolean valid = false;
        int inp = 0;

        while (!valid) { //only moves on from this switch statement if user gives a valid input
            System.out.println("Please choose the size of your drink: S) Small, M) Medium, L) Large");
            switch (userFeedback.nextLine()) {
                case "S":
                case "s":
                    basicCoffee = new SmallSize(basicCoffee); //creates a small-size coffee
                    valid = true; //makes the boolean true if user gives a valid input
                    break;
                case "M":
                case "m":
                    basicCoffee = new MediumSize(basicCoffee); //creates a medium-size coffee
                    valid = true;
                    break;
                case "L":
                case "l":
                    basicCoffee = new LargeSize(basicCoffee); //creates a large-size coffee
                    valid = true;
                    break;
                default:
                    System.out.println("Invalid Input"); //lets user know input is valid while keeping the boolean false, making it go through the switch statement again
                    break;
            }
        }

        while (inp != 1) {
            System.out.println("Enter the following values to add toppings: 1) Milk, 2) Hot Water, 3) Espresso, 4) Sugar, 5) Whipped Cream, e - to complete order");
            switch (userFeedback.nextLine()) {
                case "1":
                    if (inpArr[1] > 0) {
                        basicCoffee = new Milk(basicCoffee); //adds milk to coffee if user returns "1"
                        inpArr[1]--;
                    }
                    else
                        System.out.println("Out of Milk. Try a different topping."); //lets the user know this if there is no milk left
                    break;
                case "2":
                    if (inpArr[2] > 0) {
                        basicCoffee = new HotWater(basicCoffee); //adds hot water to coffee if user returns "2"
                        inpArr[2]--;
                    }
                    else
                        System.out.println("Out of Hot Water. Try a different topping."); //lets the user know this if there is no hot water left
                    break;
                case "3":
                    if (inpArr[3] > 0) {
                        basicCoffee = new Espresso(basicCoffee); //adds espresso to coffee if user returns "3"
                        inpArr[3]--;
                    }
                    else
                        System.out.println("Out of Espresso. Try a different topping."); //lets the user know this if there is no espresso left
                    break;
                case "4":
                    if (inpArr[4] > 0) {
                        basicCoffee = new Sugar(basicCoffee); //adds sugar to coffee if user returns "4"
                        inpArr[4]--;
                    }
                    else
                        System.out.println("Out of Sugar. Try a different topping."); //lets the user know this if there is no sugar left
                    break;
                case "5":
                    if (inpArr[5] > 0) {
                        basicCoffee = new WhippedCream(basicCoffee); //adds whipped creat to coffee if user returns "5"
                        inpArr[5]--;
                    }
                    else
                        System.out.println("Out of Whipped Cream. Try a different topping."); //lets user know this if there is no whipped cream left
                    break;
                case "e":
                    inp = 1;
                    break;
                default:
                    System.out.println("Invalid Input");
            }
            coffeeOrder.add(basicCoffee);
        }
        return coffeeOrder;
    }

    public static int[] inventoryReader() {
        try {
            BufferedReader reader = new BufferedReader(new FileReader("Inventory.txt"));
            for (int i = 0; i < inpArr.length; ++i) {
                String input = reader.readLine();
                System.out.println(input);
                inpArr[i] = Integer.valueOf(input.substring(input.indexOf("=")+2)); //adds the int value in each line to the array
            }
        }
        catch (IOException io) {
            System.out.println(io);
        }
        return inpArr;
    }

    public static void inventoryWriter(int[] arr) {
        try {
            FileWriter inWrite = new FileWriter("Inventory.txt");
            inWrite.write("Black Coffee = " +arr[0]+ "\n");
            inWrite.write("Milk = " +arr[1]+ "\n");
            inWrite.write("HotWater = " +arr[2]+ "\n");
            inWrite.write("Espresso = " +arr[3]+ "\n");
            inWrite.write("Sugar = " +arr[4]+ "\n");
            inWrite.write("Whipped Cream = " +arr[5]+ "\n");
            inWrite.flush();
            inWrite.close();
            System.out.println("Successfully updated the inventory");
        }
        catch (IOException e) {
            System.out.println(e);
        }
    }

    public static void logWriter(Stack<String> orders) {
        try {
            FileWriter logWrite = new FileWriter("LogFile.txt", true);
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd 'at' HH:mm:ss z\n");
            Date date = new Date(System.currentTimeMillis());
            logWrite.write("\n\nWriting orders from stack " +formatter.format(date));
            if (!orders.empty()) {
                logWrite.write(orders.pop());
                System.out.println("Successfully updated the log file");
            }
            else {
                System.out.println("Nothing to log. Stack is empty");
            }
            logWrite.flush();
            logWrite.close();
        }
        catch (IOException e) {
            System.out.println(e);
        }
    }
}